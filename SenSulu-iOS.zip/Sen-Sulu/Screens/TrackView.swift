import SwiftUI
import UIKit

struct TrackView: View {
    @Environment(AppState.self) private var state
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    @State private var copied = false
    @State private var showReceipt = false

    var body: some View {
        VStack(spacing: 0) {
            if let order = state.order {
                header(order)
                ScrollView(.vertical) {
                    VStack(alignment: .leading, spacing: 0) {
                        trackBox(order)
                        timeline(order)
                        HStack(spacing: 8) {
                            SSButton(title: "Электронный чек", style: .outline, height: 52) { showReceipt = true }
                            SSButton(title: "WhatsApp", height: 52) { openURL(Links.whatsapp) }
                        }
                        .padding(.horizontal, 24)
                        .padding(.top, 8)
                    }
                    .padding(.bottom, 30)
                }
                .scrollIndicators(.hidden)
            }
        }
        .background(Color.ssIvory.ignoresSafeArea())
        .sensoryFeedback(.success, trigger: state.order?.stage ?? 0)
        .sheet(isPresented: $showReceipt) {
            if let order = state.order { ReceiptView(order: order).presentationDetents([.medium, .large]) }
        }
    }

    private func header(_ order: Order) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Button { dismiss() } label: {
                Image(systemName: "xmark").font(.system(size: 17, weight: .light)).foregroundStyle(Color.ssIvory)
                    .frame(width: 44, height: 44)
            }
            .padding(.leading, -12)
            .accessibilityLabel("Закрыть")
            Caps("Заказ \(order.number)", size: 10, spacing: 0.3, color: .ssGold)
            Text("Рахмет, \(state.name).").font(.serif(40)).foregroundStyle(Color.ssIvory)
            Text("Статус доставки — здесь. Трек-номер искать в переписке больше не нужно.")
                .font(.mont(12)).lineSpacing(4).foregroundStyle(Color.ssSand)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 24)
        .padding(.top, 8)
        .padding(.bottom, 26)
        .background(Color.ssInk.ignoresSafeArea(edges: .top))
    }

    private func trackBox(_ order: Order) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Caps("\(order.delivery == .cdek ? "СДЭК" : "Казпочта") · трек-номер", size: 10, spacing: 0.24, color: .ssMuted)
                Text(order.track).font(.mont(15)).tracking(15 * 0.08)
            }
            Spacer()
            Button {
                UIPasteboard.general.string = order.track.replacingOccurrences(of: " ", with: "")
                withAnimation { copied = true }
            } label: {
                Caps(copied ? "Скопировано" : "Копировать", size: 11, spacing: 0.14)
                    .padding(.horizontal, 14)
                    .frame(height: 40)
                    .overlay(Rectangle().stroke(Color.ssInk, lineWidth: 1))
            }
            .buttonStyle(PressStyle())
            .sensoryFeedback(.success, trigger: copied)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 16)
        .overlay(Rectangle().stroke(Color.ssLine2, lineWidth: 1))
        .padding(.horizontal, 24)
        .padding(.top, 20)
    }

    private func timeline(_ order: Order) -> some View {
        let steps = order.steps
        return VStack(alignment: .leading, spacing: 0) {
            ForEach(Array(steps.enumerated()), id: \.offset) { i, step in
                let done = i <= order.stage
                let current = i == order.stage
                HStack(alignment: .top, spacing: 16) {
                    VStack(spacing: 0) {
                        ZStack {
                            Circle()
                                .fill(current ? Color.ssGold : (done ? Color.ssInk : Color.clear))
                                .frame(width: 14, height: 14)
                            Circle()
                                .strokeBorder(current ? Color.ssInk : (done ? Color.ssInk : Color(hex: 0xA39C97)), lineWidth: current ? 3 : 1)
                                .frame(width: 14, height: 14)
                        }
                        .scaleEffect(current ? 1.15 : 1)
                        if i < steps.count - 1 {
                            Rectangle().fill(i < order.stage ? Color.ssInk : Color.ssLine2).frame(width: 1).frame(minHeight: 34)
                        }
                    }
                    .frame(width: 14)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(step.0).font(.mont(13, current ? .semibold : .regular))
                            .foregroundStyle(done ? Color.ssInk : Color.ssMuted2)
                        Text(done ? step.1 : "Ожидается").font(.mont(11)).foregroundStyle(Color.ssMuted)
                    }
                    .padding(.top, -2)
                    .padding(.bottom, 18)
                }
            }
        }
        .padding(.horizontal, 24)
        .padding(.top, 26)
        .animation(.spring(duration: 0.5), value: order.stage)
    }
}

struct ReceiptView: View {
    let order: Order

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                LogoLockup()
                Spacer()
                Caps("Чек", size: 11, spacing: 0.24, color: .ssMuted)
            }
            .padding(.top, 28)
            Text("Заказ \(order.number)").font(.serif(30)).padding(.top, 18)
            VStack(spacing: 10) {
                ForEach(order.items) { item in
                    HStack(alignment: .top) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.product.name).font(.mont(13))
                            Text("\(item.qty) × \(tenge(item.product.price))").font(.mont(11)).foregroundStyle(Color.ssMuted)
                        }
                        Spacer()
                        Text(tenge(item.total)).font(.mont(13))
                    }
                }
                Rectangle().fill(Color.ssLine).frame(height: 1)
                HStack { Text("Доставка").font(.mont(13)); Spacer(); Text(tenge(order.delivery.price)).font(.mont(13)) }
                HStack { Text("Оплата").font(.mont(13)); Spacer(); Text(order.payment.rawValue).font(.mont(13)) }
                HStack(alignment: .lastTextBaseline) {
                    Caps("Итого", size: 11, spacing: 0.24)
                    Spacer()
                    Text(tenge(order.total)).font(.serif(28))
                }
                .padding(.top, 6)
            }
            .padding(.top, 20)
            Spacer()
        }
        .padding(.horizontal, 24)
        .foregroundStyle(Color.ssInk)
        .background(Color.ssIvory.ignoresSafeArea())
    }
}
